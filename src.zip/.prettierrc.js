module.exports = {
    semi: false,
    singleQuote: true,
    bracketSpacing: true,
    printWidth: 100,
    tabWidth: 2,
}
