export const URLs = {
  auth: '/auth',
  dashboard: '/dashboard',
  review: '/review',
  lessons: '/lessons',
  studyLists: '/study-lists',
  progress: '/progress',
}
