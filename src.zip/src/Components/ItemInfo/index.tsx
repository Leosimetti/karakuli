import ItemInfo from './ItemInfo';

export default ItemInfo;
