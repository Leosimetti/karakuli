import CharacterDisplay from './CharacterDisplay';

export default CharacterDisplay;
