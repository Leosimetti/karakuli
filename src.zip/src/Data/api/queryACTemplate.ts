// export const queryAC =
//   (queryCallback, onSuccessCallback, onFailCallback) => async (dispatch: any) => {}
